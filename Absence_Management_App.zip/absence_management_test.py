from django.test import TestCase
from django.contrib.auth.models import User
from django.urls import reverse
from .models import AbsenceRequest
from .forms import AbsenceForm

class AbsenceModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.absence = AbsenceRequest.objects.create(
            user=self.user,
            start_date='2025-03-01',
            end_date='2025-03-05',
            reason='Medical Leave',
            status='Pending'
        )

    def test_absence_has_correct_attributes(self):
        self.assertEqual(self.absence.start_date, '2025-03-01')
        self.assertEqual(self.absence.end_date, '2025-03-05')
        self.assertEqual(self.absence.reason, 'Medical Leave')
        self.assertEqual(self.absence.status, 'Pending')

class AbsenceViewTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.client.login(username='testuser', password='testpass')
        self.absence = AbsenceRequest.objects.create(
            user=self.user,
            start_date='2025-03-01',
            end_date='2025-03-05',
            reason='Medical Leave',
            status='Pending'
        )

    def test_absence_list_view(self):
        response = self.client.get(reverse('absence_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Medical Leave')

    def test_absence_detail_view(self):
        response = self.client.get(reverse('absence_detail', args=[self.absence.id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Medical Leave')

    def test_absence_create_view(self):
        response = self.client.post(reverse('absence_create'), {
            'start_date': '2025-04-01',
            'end_date': '2025-04-05',
            'reason': 'Vacation'
        })
        self.assertEqual(response.status_code, 302)  # Redirect after successful form submission
        self.assertEqual(AbsenceRequest.objects.count(), 2)

    def test_absence_delete_view(self):
        response = self.client.post(reverse('absence_delete', args=[self.absence.id]))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(AbsenceRequest.objects.count(), 0)

class AbsenceFormTest(TestCase):
    def test_valid_form(self):
        form_data = {'start_date': '2025-06-01', 'end_date': '2025-06-10', 'reason': 'Family Event'}
        form = AbsenceForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_invalid_form(self):
        form_data = {'start_date': '', 'end_date': '', 'reason': ''}  
        form = AbsenceForm(data=form_data)
        self.assertFalse(form.is_valid())
