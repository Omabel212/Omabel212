from django.shortcuts import render, get_object_or_404, redirect
from .models import LeaveRequest
from .forms import LeaveRequestForm

def leave_list(request):
    """View all leave requests."""
    leaves = LeaveRequest.objects.all()
    return render(request, "absences/leave_list.html", {"leaves": leaves})

def leave_detail(request, pk):
    """View details of an individual leave request."""
    leave = get_object_or_404(LeaveRequest, pk=pk)
    return render(request, "absences/leave_detail.html", {"leave": leave})

def leave_create(request):
    """Create a new leave request."""
    if request.method == "POST":
        form = LeaveRequestForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("leave_list")  # ✅ Redirect after submission
    else:
        form = LeaveRequestForm()
    return render(request, "absences/leave_request.html", {"form": form})

def success_page(request):
    """Show success message after leave request submission."""
    return render(request, "absences/success.html")

def leave_update(request, pk):
    """Update an existing leave request."""
    leave = get_object_or_404(LeaveRequest, pk=pk)
    if request.method == "POST":
        form = LeaveRequestForm(request.POST, instance=leave)
        if form.is_valid():
            form.save()
            return redirect("leave_list")
    else:
        form = LeaveRequestForm(instance=leave)
    return render(request, "absences/leave_form.html", {"form": form})

def leave_delete(request, pk):
    """Delete a leave request."""
    leave = get_object_or_404(LeaveRequest, pk=pk)
    leave.delete()
    return redirect("leave_list")
