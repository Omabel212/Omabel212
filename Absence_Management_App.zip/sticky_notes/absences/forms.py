from django import forms
from .models import LeaveRequest

class LeaveRequestForm(forms.ModelForm):
    class Meta:
        model = LeaveRequest
        fields = ["employee_name", "leave_type", "start_date", "end_date", "reason", "status"]
        widgets = {
            "start_date": forms.DateInput(attrs={"type": "date"}),  # ✅ Show calendar
            "end_date": forms.DateInput(attrs={"type": "date"}),  # ✅ Show calendar
            "leave_type": forms.Select(),  # ✅ Dropdown for leave type
        }
