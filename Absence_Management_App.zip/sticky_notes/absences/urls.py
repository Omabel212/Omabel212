from django.urls import path
from . import views

urlpatterns = [
    path("", views.leave_list, name="leave_list"),
    path("new/", views.leave_create, name="leave_create"),
    path("success/", views.success_page, name="success_page"),
    path("<int:pk>/", views.leave_detail, name="leave_detail"),  # ✅ New view page
    path("<int:pk>/edit/", views.leave_update, name="leave_update"),  # ✅ Update page
    path("<int:pk>/delete/", views.leave_delete, name="leave_delete"),
]
