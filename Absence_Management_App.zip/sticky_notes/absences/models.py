from django.db import models

class LeaveRequest(models.Model):
    LEAVE_TYPES = [
        ("Holiday", "Holiday"),
        ("Maternity", "Maternity Leave"),
        ("Sick", "Sick Leave"),
        ("Unpaid", "Unpaid Leave"),
    ]

    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("Approved", "Approved"),
        ("Rejected", "Rejected"),
    ]

    employee_name = models.CharField(max_length=100)
    leave_type = models.CharField(max_length=20, choices=LEAVE_TYPES)
    start_date = models.DateField()
    end_date = models.DateField()
    reason = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="Pending")
    created_at = models.DateTimeField(auto_now_add=True)  # ✅ Fix: Automatically set created_at

    def __str__(self):
        return f"{self.employee_name} - {self.leave_type} ({self.status})"
